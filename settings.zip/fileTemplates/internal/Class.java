#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
*
*
* @author: lh
*
* @create: ${YEAR}-${MONTH}-${DAY}
**/
public class ${NAME} {
}
